#' trim_all_excess_space function
#'
#' This function trims all excess whitespace. 
#' @param x A character vector.
#' @keywords whitespace
#' @export
#' @examples trim_all_excess_space("   ccc   aa  bbb ")
#' trim_all_excess_space()

trim_all_excess_space <- function(x){
	x <- trimws(x)
	x <- gsub("\\s+", " ", x)
	x
}