#' regex_count_extraction function
#'
#' This couns numbers of a given pattern type. Uses the stringr package.
#' @param x A data frame with a column named strings.
#' @keywords feature extraction
#' @export
#' @examples
#' regex_count_extraction()

regex_count_extraction <- function(x){
	x$num_commas <- str_count(x$strings, ',')
	x$num_ing <- str_count(x$strings, 'ing')
	x$num_ed <- str_count(x$strings, 'ed')
	x$num_ly <- str_count(x$strings, 'ly')
	x$num_appos <- str_count(x$strings, "'")
	x
}
