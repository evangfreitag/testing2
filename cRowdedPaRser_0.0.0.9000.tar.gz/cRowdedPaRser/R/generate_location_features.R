#' generate_location_features function
#'
#' This does various counting activities 
#' @param x A character vector.
#' @keywords feature extraction
#' @export
#' @examples
#' generate_location_features()

generate_location_features <- function(x){
	x$row_names <- seq(1:length(x$strings))
	x$perc_from_top <- 1 - (1/as.numeric(x$row_names))
	x$perc_num_char <- nchar(x$strings)/sum(nchar(x$strings))
	x$num_char <- nchar(x$strings)
	x
}