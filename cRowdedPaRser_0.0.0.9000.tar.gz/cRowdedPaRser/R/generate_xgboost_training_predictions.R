#' generate_xgboost_training_predictions function
#'
#' This generates a new xgboost model
#' @param x A dataframe.
#' @keywords feature extraction
#' @export
#' @examples
#' generate_xgboost_training_predictions()

generate_xgboost_training_predictions <- function(model,test_set,test_labels,class_codes){
	pr1 <- predict(model, test_set)
	pr1 <- matrix(pr1, ncol=10, byrow=TRUE) # reshape it to a num_class-columns matrix
	predicted_labels <- max.col(pr1) - 1 # convert the probabilities to softmax labels

	for(i in 1:length(class_codes$code)){
		class_code <- class_codes$code[i]
		class_name <- class_codes$name[i]
		w <- which(test_labels == class_code)
		test_labels[w] <- class_name
		w <- which(predicted_labels == class_code)
		predicted_labels[w] <- class_name
	}
	print(confusionMatrix(predicted_labels, test_labels))
	return(predicted_labels)
}

