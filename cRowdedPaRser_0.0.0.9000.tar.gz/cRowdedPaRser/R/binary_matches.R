#' binary_matches function
#'
#' This checks for "loose" matches (i.e. the word occurs anywhere in the string).
#' @param x, y character vectors.
#' @keywords feature extraction
#' @export
#' @examples
#' binary_matches()

binary_matches <- function(x,y){
	z <- rep(0,length(x))
	x <- paste0(" ", tolower(x), " ", collapse = NULL)
	y <- paste0(" ", tolower(y), " ", collapse = NULL)
	for(i in 1:length(y)){		
		w <- grep(y[i], x, fixed = TRUE)
		if(length(w) > 0){z[w] <- 1}
	}
	return(z)
}
