#' qdap_regex_extraction function
#'
#' This checks for several pattern types and generates a 0-1 feature. Uses the qdapRegex package
#' @param x A data frame with a column named strings.
#' @keywords feature extraction
#' @export
#' @examples
#' qdap_regex_extraction()

qdap_regex_extraction <- function(x){
	x <- find_ones(x, ex_email(tolower(x$strings)), "contains_email")
	x <- find_ones(x, ex_phone(tolower(x$strings)), "contains_phone")
	x <- find_ones(x, ex_city_state_zip(x$strings), "contains_city_state_zip")
	x <- find_ones(x, ex_url(tolower(x$strings)), "contains_url")
	x <- find_ones(x, ex_postal_code(x$strings), "contains_zip_code")
	x <- find_ones(x, ex_city_state(x$strings), "contains_city_state")
	x <- find_ones(x, ex_caps_phrase(x$strings), "contains_caps_phrase")
	x <- find_ones(x, ex_caps(x$strings), "contains_caps")
	x <- find_ones(x, ex_abbreviation(x$strings), "contains_dollar")
	x <- find_ones(x, ex_dollar(x$strings), "contains_abbrev")
	x <- find_ones(x, ex_number(x$strings), "contains_number")
	x <- find_ones(x, ex_percent(x$strings), "contains_percentage")
	x <- find_ones(x, ex_non_words(tolower(x$strings)), "contains_non_words")
	x <- find_ones(x, ex_endmark(x$strings), "contains_endmark")
	x <- find_ones(x, ex_title_name(x$strings), "contains_title_name")
	x
}