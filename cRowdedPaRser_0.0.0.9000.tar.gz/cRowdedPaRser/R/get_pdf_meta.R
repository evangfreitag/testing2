#' get_pdf_meta function
#'
#' This function retrieves metadata from a pdf using the "tabulizer" package. 
#' @param file_location A character vector of file locations.
#' @keywords meta
#' @export
#' @examples pdf_list <- get_pdf_meta("C:/Users/Evan/Documents/Crowded2/src")
#' get_pdf_meta()

get_pdf_meta <- function(file_location){

	files_in_dir <- list.files(file_location)
	w <- which(endsWith(files_in_dir,"pdf") == TRUE)
	pdf_files_in_dir <- files_in_dir[w]

	raw_meta <- list()
	pdf_meta_out_list <- list()

	for(i in 1:length(pdf_files_in_dir)){
		url_name <- paste(file_location, pdf_files_in_dir[i],sep ="/")
		raw_meta[[i]] <- try(extract_metadata(url_name))		
		pdf_meta_out_list[[i]] <- try(unlist(raw_meta))
	}	
	names(pdf_meta_out_list) <- pdf_files_in_dir
	return(pdf_meta_out_list)
}