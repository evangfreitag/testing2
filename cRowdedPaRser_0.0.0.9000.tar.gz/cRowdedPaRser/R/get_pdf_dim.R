#' get_pdf_dim function
#'
#' This function retrieves the dimensions of a pdf using the "tabulizer" package. 
#' @param file_location A character vector of file locations.
#' @keywords meta
#' @export
#' @examples pdf_list <- get_pdf_dim("C:/Users/Evan/Documents/Crowded2/src")
#' get_pdf_dim()

get_pdf_dim <- function(file_location){

	files_in_dir <- list.files(file_location)
	w <- which(endsWith(files_in_dir,"pdf") == TRUE)
	pdf_files_in_dir <- files_in_dir[w]

	raw_dim <- list()
	pdf_dim_out_list <- list()

	for(i in 1:length(pdf_files_in_dir)){
		url_name <- paste(file_location, pdf_files_in_dir[i],sep ="/")
		raw_dim[[i]] <- try(get_page_dims(url_name))		
		pdf_dim_out_list[[i]] <- raw_dim
		print(raw_dim)
	}	
	names(pdf_dim_out_list) <- pdf_files_in_dir
	return(pdf_dim_out_list)
}