#' find_symbols function
#'
#' This function finds a given string of text and generates and indicator variable. 
#' @param x,symbol,indicator A character, a symbol(character), name of new variable vector of file locations.
#' @keywords feature extraction
#' @export
#' @examples 
#' find_symbols()

find_symbols <- function(x, symbol, indicator){
	x[,c(indicator)] <- 0
	w <- grep(symbol, x$strings, fixed = TRUE)
	if(length(w) > 0){x[w,c(indicator)] <- 1}
	x
}
