#' generate_xgboost_model function
#'
#' This generates a new xgboost model
#' @param x A dataframe.
#' @keywords feature extraction
#' @export
#' @examples
#' generate_xgboost_model()

generate_xgboost_model <- function(data){
	data$strings_trimmed <- NULL	
	data$file_name <- NULL	

	data_and_class_codes <- get_set_classification_codes(data)
	data <- data_and_class_codes[[2]]
	class_codes <- data_and_class_codes[[1]]

	set.seed(1113)
	smp_size <- floor(0.9 * nrow(data))
	train_ind <- sample(seq_len(nrow(data)), size = smp_size)

	train <- data[train_ind, ]
	test <- data[-train_ind, ]

	train$row_names <- as.numeric(train$row_names)
	test$row_names <- as.numeric(test$row_names)

	train_row_names <- train$row_names
	train$row_names <- NULL
	strings_train <- train$strings
	train$strings <- NULL

	test_row_names <- test$row_names
	test$row_names <- NULL
	strings_test <- test$strings
	test$strings <- NULL

	train_resume_number <- train$resume_number
	train$resume_number <- NULL

	test_resume_number <- test$resume_number
	test$resume_number <- NULL

	train$classification_coded <- as.numeric(trimws(train$classification_coded))
	test$classification_coded <- as.numeric(trimws(test$classification_coded))

	y_train <- train$classification_coded
	y_train_text <- train$classification
	train$classification <- NULL
	train$classification_coded <- NULL

	y_test <- test$classification_coded
	y_test_text <- test$classification
	test$classification <- NULL
	test$classification_coded <- NULL

	dtrain <- xgb.DMatrix(data = as.matrix(train), label = y_train)
	dtest <- xgb.DMatrix(data = as.matrix(test), label = y_test)

	param <- list(max_depth = 70, 
		eta = .01, 
		gamma = .7,
		min_child_weight = .5,
		nthread = 26,
		objective = "multi:softprob",
		colsample_bytree = 0.6,
		subsample = 0.6,
		num_class = 10, 
		silent = 1,
		eval_metric = "mlogloss"
	)

	watchlist <- list(eval = dtest, train = dtrain)
	model <- xgb.train(param, data = dtrain, nrounds = 10, early_stopping_rounds = 8, watchlist, print_every_n = 10)
	print(class_codes)
	save(class_codes, file="class_codes.RData")
	predictions <- getXgPred(model,dtest,y_test,class_codes)
	return(model)
}