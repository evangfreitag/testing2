#' get set classification codes function
#'
#' Converts a character representation to integer and returns a lookup
#' @param x A list of dataframes.
#' @keywords feature extraction
#' @export
#' @examples
#' get_set_classification_codes()

get_set_classification_codes <- function(data){
	classes1 <- unique(data$classification)
	data$classification_coded <- 0
	classification_codes <- rep(0,length(classes1))
	for(i in 1:length(classes1)){	
		classification_codes[i] <- (i - 1)
		w1 <- which(data$classification == classes1[i])
		data$classification_coded[w1] <- (i - 1)
	}
	classification_codes <- cbind(classes1, classification_codes)
	classification_codes <- as.data.frame(classification_codes, stringsAsFactors = FALSE)
	colnames(classification_codes) <- c("name","code")
	return(list(classification_codes,data))
}
